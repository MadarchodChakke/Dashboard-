"use client";

import { cn } from "@/lib/utils";
import { SidebarDemo } from "@/components/practice-session";
import { Button } from "@/components/ui/button";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/lib/theme-provider";

export function Navbar() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="flex h-screen">
      <SidebarDemo />
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 right-4 z-50 md:right-4 md:fixed hidden md:flex"
        onClick={toggleTheme}
      >
        {theme === 'dark' ? (
          <Moon className="h-5 w-5" />
        ) : (
          <Sun className="h-5 w-5" />
        )}
      </Button>
    </div>
  );
}