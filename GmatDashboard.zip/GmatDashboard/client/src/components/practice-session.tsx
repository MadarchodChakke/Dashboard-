"use client";
import React, { useState } from "react";
import { Sidebar, SidebarBody, SidebarLink } from "@/components/ui/sidebar";
import { GraduationCap, Languages, Brain, LineChart, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Logo } from "@/components/logo";
import { cn } from "@/lib/utils";

interface PracticeSession {
  id: number;
  date: string;
  time: string;
  sections: string[];
}

export function SidebarDemo() {
  const links = [
    {
      label: "GRE",
      href: "#",
      icon: <GraduationCap className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "IELTS",
      href: "#",
      icon: <Languages className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "AI",
      href: "#",
      icon: <Brain className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "Progress",
      href: "#",
      icon: <LineChart className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />,
    },
    {
      label: "Logout",
      href: "#",
      icon: <LogOut className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />,
    },
  ];

  const [open, setOpen] = useState(false);
  const [sessions, setSessions] = useState<PracticeSession[]>([]);

  const createSession = () => {
    const newSession: PracticeSession = {
      id: sessions.length + 1,
      date: new Date().toLocaleDateString(),
      time: "45 mins",
      sections: ["Quant", "Data Insights", "Verbal"],
    };
    setSessions([newSession, ...sessions]);
  };

  const isMobile = () => window.innerWidth <= 768;

  return (
    <div className="flex flex-1 flex-col md:flex-row min-h-screen bg-background">
      <Sidebar open={open} setOpen={setOpen}>
        <SidebarBody className="justify-between gap-10">
          <div className="flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
            <Logo />
            <div className="mt-8 flex flex-col gap-2">
              {links.map((link, idx) => (
                <SidebarLink key={idx} link={link} />
              ))}
            </div>
          </div>
          <div>
            <SidebarLink
              link={{
                label: "User Profile",
                href: "#",
                icon: (
                  <div className="h-7 w-7 rounded-full bg-black dark:bg-white flex-shrink-0" />
                ),
              }}
            />
          </div>
        </SidebarBody>
      </Sidebar>

      <main className="flex-1 p-4 flex flex-col items-center">
        <Button
          onClick={createSession}
          className={cn(
            "mt-4 transition-all duration-300 bg-black text-white dark:bg-white dark:text-black hover:bg-neutral-800 dark:hover:bg-neutral-200",
            sessions.length > 0 ? "translate-y-0" : "translate-y-[40vh]"
          )}
        >
          Create Session →
        </Button>

        <AnimatePresence>
          {sessions.map((session) => (
            <motion.div
              key={session.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-md md:max-w-3xl mt-4 p-4 border rounded-lg transition-all duration-300 hover:border-black dark:hover:border-white mx-auto"
            >
              <div className="flex flex-col md:flex-row md:justify-between">
                <div>
                  <h3 className="font-bold">Practice Session {session.id}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    {session.date} • {session.time}
                  </p>
                  {!isMobile() && (
                    <div className="flex gap-2 mt-2">
                      {session.sections.map((section, idx) => (
                        <span
                          key={idx}
                          className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded"
                        >
                          {section}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="flex flex-col gap-2 mt-2">
                  <Button variant="outline" size="sm" className="w-full">
                    AI Analysis
                  </Button>
                  <Button variant="outline" size="sm" className="w-full">
                    Retake
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </main>
    </div>
  );
}