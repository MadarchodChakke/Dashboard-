import { motion } from "framer-motion";
import { Link } from "wouter";

export const Logo = () => {
  return (
    <Link
      href="/"
      className="font-helvetica flex space-x-2 items-center text-sm text-black dark:text-white py-1 relative z-20"
    >
      <div className="h-5 w-6 bg-black dark:bg-white rounded-br-lg rounded-tr-sm rounded-tl-lg rounded-bl-sm flex-shrink-0" />
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="font-medium whitespace-pre"
      >
        TestOverseas
      </motion.span>
    </Link>
  );
};