import { Navbar } from "@/components/ui/navbar";

export default function Dashboard() {
  return <Navbar />;
}
